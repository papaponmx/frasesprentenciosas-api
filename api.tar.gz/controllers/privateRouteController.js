/**
 * privateRoute
 * 
 * Checks validation headers
 */

const privateRoute = req => {
};


module.exports = privateRoute;